import random
from flask import Flask, render_template, request
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime

def init_google_sheets():
    scope = [
        "https://spreadsheets.google.com/feeds",
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive.file",
        "https://www.googleapis.com/auth/drive"
    ]
    creds = ServiceAccountCredentials.from_json_keyfile_name(
        "C:\\Users\\STUDENT\\Desktop\\New Folder\\service_account.json", scope)
    client = gspread.authorize(creds)
    sheet = client.open("MATHQUIZ").sheet1

    # Insert headers if sheet is empty
    if not sheet.row_values(1):
        sheet.insert_row(["Name", "Question", "User Answer", "Correct Answer", "Status", "Timestamp"], 1)
    return sheet

def generate_question():
    num1, num2 = random.randint(1, 20), random.randint(1, 10)
    op = random.choice(['+', '-', '*', '/'])
    if op == '/':
        # Make sure division is exact for simplicity
        num1 = num2 * random.randint(1, 10)
        correct_answer = num1 // num2
    else:
        correct_answer = eval(f"{num1}{op}{num2}")
    return f"{num1} {op} {num2}", correct_answer

app = Flask(__name__)
sheet = init_google_sheets()

@app.route('/hi')
def index():
    quiz = [generate_question() for _ in range(5)]  # list of (question, correct_answer)
    questions = [q for q, a in quiz]
    answers = [a for q, a in quiz]
    return render_template('form.html', questions=questions, correct_answers=answers)

@app.route('/anyname', methods=['POST'])
def insertdata():
    name = request.form.get('name')
    questions = [request.form.get(f'question{i}') for i in range(1,6)]
    user_answers = [request.form.get(f'answer{i}') for i in range(1,6)]
    correct_answers = [request.form.get(f'correct_answer{i}') for i in range(1,6)]

    for q, user_a, correct_a in zip(questions, user_answers, correct_answers):
        try:
            user_val = float(user_a)
            correct_val = float(correct_a)
            status = "Correct" if abs(user_val - correct_val) < 1e-5 else "Incorrect"
        except:
            status = "Incorrect"

        row = [name, q, user_a, correct_a, status, datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
        sheet.append_row(row)

    return "Data inserted successfully!"

if __name__ == '__main__':
    app.run(debug=True, port=8000)
